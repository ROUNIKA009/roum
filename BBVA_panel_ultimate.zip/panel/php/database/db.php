<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php database
*/
debug_backtrace() || die ("Direct access not permitted.");
$connection = new mysqli('localhost','root','','panelsito');
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$connection->set_charset('utf8');
$connection->query('SET NAMES utf8');
$inicio = microtime(true);

?>