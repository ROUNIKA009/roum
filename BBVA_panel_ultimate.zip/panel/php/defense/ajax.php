<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php para proteger solo calls ajax
*/
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
/* If not ajax , restrict the newbie */
if(!IS_AJAX):
	/* Log Browser, Ip, cookie  and send email (Coming soon)*/
die('Restricted access');
endif;