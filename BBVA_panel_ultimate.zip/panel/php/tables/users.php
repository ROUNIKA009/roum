<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php tabla de usuarios
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$usuarios= $connection->query("SELECT * FROM tbl_users WHERE NOT (user_id = '" .$_SESSION['userSession']."') order by user_id desc LIMIT 80");
echo '


<table class="responsive-table custom-table striped neonetxxx">
              <thead>
                <tr>
                    <th class="custom-th">Usuario</th>
                    <th class="custom-th">Rango</th>
                    <th class="custom-th">Correo</th>
                    <th class="custom-th">Acciones</th>
                </tr>
              </thead>
              <tbody>';
if(mysqli_num_rows($usuarios) === 0):
?>

<tr>
<td colspan="5">No hay usuarios registrados</td></tr>
<?php
endif;
while($row = mysqli_fetch_array($usuarios)):
?>
<tr>
<td><?php echo htmlentities($row['username']); ?></td>
      <td><?php echo htmlentities($row['rango']); ?></td>
      <td><?php if (empty($row['email'])) {echo 'Usuario sin Correo Electrónico';}else {echo htmlentities($row['email']);} ?></td>
<?php if ($userRow['rango'] === 'root'): ?>
      <td><a class="edit flat btn no-shadow open-ios" data-id="<?php echo $row['user_id']; ?>"><i class="material-icons">edit</i></a> <a class="btn delete pink accent-1 no-shadow" data-id="<?php echo $row['user_id']; ?>"><i class="material-icons">delete_forever</i></a></td>
<?php endif; ?>
<?php if ($userRow['rango'] === 'empleado'): ?>
      <td>No Disponible</td>
<?php endif; ?>
    </tr>

 <?php
 endwhile;
 echo '</tbody></table>';}



 ?>