<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que nos agrega clientes
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
if (!empty($_POST['nombre'])) {
$hash = @$_COOKIE['identificator'];
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$nombre = $connection->real_escape_string($_POST['nombre']);
$correo = $connection->real_escape_string($_POST['correo']);
$telefono = $connection->real_escape_string($_POST['telefono']);
$direccion = $connection->real_escape_string($_POST['direccion']);
$notas = $connection->real_escape_string($_POST['notas']);
$control = $connection->query("INSERT INTO clientes (nombre,direccion,correo,telefono,notas) values ('$nombre','$direccion','$correo','$telefono','$notas')");}}