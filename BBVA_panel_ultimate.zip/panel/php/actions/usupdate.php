<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que nos actualiza usuarios
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
if (!empty($_POST['id'])) {
if ($userRow['rango'] === 'root'){

$id = $connection->real_escape_string(@$_POST['id']);
$nombre = $connection->real_escape_string(@$_POST['nombre']);
$correo = $connection->real_escape_string(@$_POST['email']);
$username = $connection->real_escape_string(@$_POST['username']);
$update = $connection->query("UPDATE tbl_users set nombre='$nombre',email='$correo',username='$username' where user_id='$id'");
}}}