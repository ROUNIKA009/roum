<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que nos elimina clientes
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
if (!empty($_POST['id'])) {
$id= htmlspecialchars($connection->real_escape_string($_POST['id']));
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
while($row = $query->fetch_assoc()){
if ($row['rango'] === 'root') {
$clientes= $connection->query("DELETE FROM clientes WHERE id=$id");}
}}}