<?php
/**
* PANEL PRIV8 LIVE
* @package    lock.php
* @author     https://t.me/neo_net
* @copyright  2021
* @version    2.0
* Info :  PHP Calendar Block Days
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
if ($userRow['rango'] === 'root') {
$lun = $_POST['lun'];
$mar = $_POST['mar'];
$mie = $_POST['mie'];
$jue = $_POST['jue'];
$vie = $_POST['vie'];
$sab = $_POST['sab'];
$dom = $_POST['dom'];
$update = $connection->query("UPDATE locked set status='$lun' where id=1");
$update = $connection->query("UPDATE locked set status='$mar' where id=2");
$update = $connection->query("UPDATE locked set status='$mie' where id=3");
$update = $connection->query("UPDATE locked set status='$jue' where id=4");
$update = $connection->query("UPDATE locked set status='$vie' where id=5");
$update = $connection->query("UPDATE locked set status='$sab' where id=6");
$update = $connection->query("UPDATE locked set status='$dom' where id=7");
}}