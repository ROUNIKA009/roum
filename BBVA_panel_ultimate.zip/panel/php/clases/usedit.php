<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php edita usuarios
*/

include '../database/db.php';
include '../defense/ajax.php';
$id = $connection->real_escape_string(htmlspecialchars($_POST['id']));
$edit = $connection->query("SELECT * FROM tbl_users where user_id=$id");
while($row = mysqli_fetch_array($edit)):
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
?>

 <div class="row">
        <div class="input-field col s12">
          <input id="nombre-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['nombre'])?>">
          <label for="nombre-edit">Nombre</label>
        </div>
 <div class="row">
        <div class="input-field col s12">
          <input id="username-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['username'])?>">
          <label for="username-edit">Usuario</label>
        </div>
 <div class="row">
        <div class="input-field col s12">
          <input id="email-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['email'])?>">
          <label for="email-edit">Correo</label>
        </div>
 <div class="row hide">
        <div class="input-field col s12">
          <input id="id-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['user_id'])?>">
          <label for="id-edit">Identificador</label>
        </div>
<?php
}
endwhile;
?>