<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que nos devuelve lo vendido hoy filtrado por metodo
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
date_default_timezone_set('America/Mexico_City');
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$datenow =  date('Y/m/d');

if (isset($_GET['kiler'], $_GET['filter'])) {
$demon = $connection->real_escape_string($_GET['kiler']);
$filter = $connection->real_escape_string($_GET['filter']);
$cleanerx = $connection->query("SELECT *,SUM(total) as total,(SELECT SUM(total) as total FROM ventas where fecha='$datenow' and caja='$demon' and metodo='$filter') as total FROM ventas where fecha='$datenow'");
while($rowx = mysqli_fetch_array($cleanerx)){
if ($rowx['total'] == '') {
$rowx['total'] = 0;}
echo '$'.$rowx['total'].'<i class="material-icons deep-orange-text text-accent-2">arrow_upward</i>';


}}

}