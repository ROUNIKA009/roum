<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que edita clientes
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
$id = $connection->real_escape_string(htmlspecialchars($_POST['id']));
$edit = $connection->query("SELECT * FROM clientes where id=$id");
while($row = mysqli_fetch_array($edit)):
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
?>

 <div class="row">
        <div class="input-field col s12">
          <input id="nombre-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['nombre'])?>">
          <label for="password">Nombre</label>
        </div>

 <div class="row">
        <div class="input-field col s12">
          <input id="correo-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['correo'])?>">
          <label for="password">Correo</label>
        </div>
 <div class="row">
        <div class="input-field col s12">
          <input id="telefono-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['telefono'])?>">
          <label for="password">Telefono</label>
        </div>
 <div class="row">
        <div class="input-field col s12">
          <input id="direccion-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['direccion'])?>">
          <label for="password">Dirección</label>
        </div>
 <div class="row">
        <div class="input-field col s12">
          <input id="notas-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['notas'])?>">
          <label for="password">Notas</label>
        </div>
 <div class="row hide">
        <div class="input-field col s12 hide">
          <input id="id-edit" type="text" class="validate" value="<?php echo htmlspecialchars($row['id'])?>">
          <label for="password">Identificador</label>
        </div>
<?php
}
endwhile;
?>