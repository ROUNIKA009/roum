<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que nos busca empleados
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
/* Seleccionamos las subcategorias */
if (isset($_POST['elementalis'])) {
echo '
<div class="card-panel pink accent-1 no-shadow custom-box">
<span class="white-text kgb">Primeramente, Selecciona la Categoria</span>
</div>
<select class="selection-cus" id="selection-cus">';
$clientes= $connection->query("SELECT * FROM categories where parent_id=0");
if(mysqli_num_rows($clientes)== 0):
?>
<option>Actualmente no existen Categorias</option>
<?php
endif;
echo '<option value="0" selected="selected">Ver Categorias</option>';
while($row = mysqli_fetch_array($clientes)):
?>
<option value="<?php echo $row['id']; ?>"><?php echo str_replace('-', ' ', $row['name']) ?></option>
<?php
endwhile;
echo '</select>';
}

/* Seleccionamos los servicios seleccionados */
if (isset($_POST['athalana'])) {
$cmd = htmlspecialchars($connection->real_escape_string($_POST['athalana']));
echo '
<select class="selection-custom" id="selection-custom">';
$clientes= $connection->query("SELECT * FROM categories where parent_id=".$cmd."");
if(mysqli_num_rows($clientes)== 0):
?>
<option>Actualmente no existen Categorias</option>
<?php
endif;
echo '<option value="0" selected="selected">Ver Sub Categorias</option>';
while($row = mysqli_fetch_array($clientes)):
?>
<option value="<?php echo $row['id']; ?>"><?php echo str_replace('-', ' ', $row['name']) ?></option>
<?php
endwhile;
echo '</select>';
}

/* Seleccionamos los subservicios seleccionados */
if (isset($_POST['anotherone'])) {
$cmd = htmlspecialchars($connection->real_escape_string($_POST['anotherone']));
echo '
<select class="selection-customx" id="selection-customx">';
$clientes= $connection->query("SELECT * FROM services_categories where referendum_id=".$cmd."");
if(mysqli_num_rows($clientes)== 0):
?>
<option>Actualmente no existen Perfiles</option>
<?php
endif;
echo '<option value="0" selected="selected">Ver Perfiles</option>';
while($row = mysqli_fetch_array($clientes)):
?>
<option value="<?php echo $row['id']; ?>"><?php echo str_replace('-', ' ', $row['name']) ?></option>
<?php
endwhile;
echo '</select>';
}

/* Registramos un servicio */
if (isset($_POST['nombre'])) {
if ($userRow['rango'] === 'root'):
$a = htmlspecialchars($connection->real_escape_string($_POST['nombre']));
$b = htmlspecialchars($connection->real_escape_string($_POST['tiempo']));
$c = htmlspecialchars($connection->real_escape_string($_POST['precio']));
$d = htmlspecialchars($connection->real_escape_string($_POST['id']));
$real=$connection->query("INSERT INTO services_selection(nombre,precio,tiempo,identificator) VALUES('$a','$b','$c','$d')");
endif;
}}