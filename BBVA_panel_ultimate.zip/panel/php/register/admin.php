<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php de registro de empleados
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
if ($userRow['rango'] === 'root') {
if (isset($_POST['usuario']) && $_POST['password']) {
$a = $connection->real_escape_string($_POST['usuario']);
$b = $connection->real_escape_string($_POST['correo']);
$c = $connection->real_escape_string($_POST['password']);
$e = $connection->real_escape_string($_POST['rango']);
$f = $connection->real_escape_string($_POST['telefono']);
$g = $connection->real_escape_string($_POST['nombre']);
$hashed_password = password_hash($c, PASSWORD_DEFAULT); // this function works only in PHP 5.5 or latest version
$query = "INSERT INTO tbl_users(username,email,password,rango,numero,nombre,caja,reset_code,url,direccion,activado) VALUES('$a','$b','$hashed_password','$e','$f','$g','','','','','')";
if ($connection->query($query)) {
echo $msg = 'Usuario Registrado Correctamente.';}
else {
echo $msg = 'Ocurrió un error mientras se registraba. Verifique que el correo o usuario no este en uso.';}

}
}
}