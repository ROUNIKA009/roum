<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php varificador login
*/
$hash = @$_COOKIE['identificator'];
if (!isset($_SESSION['userSession'])) {
header('Location: ./logout.php?logout&identificator='.@$_COOKIE['identificator'].'');
}
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".@$_SESSION['userSession']);
$userRow=$query->fetch_array();
$queryl = $connection->query("SELECT hash,username FROM secure WHERE hash='$hash'");
if (!isset($hash)) {
  header('Location: ./logout.php?cast=message&logout&identificator='.@$_COOKIE['identificator'].'');
}
if ($queryl->num_rows === 0) {
  exit(header('Location: ./logout.php?cast=message&logout&identificator='.@$_COOKIE['identificator'].''));
}