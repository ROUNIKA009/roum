$(function(){
$("#search_cl").keyup(function() {
if($(this).val().length > 0) {
var inputSearch = $(this).val();
var dataString = 'searchword='+ inputSearch;
if(inputSearch!='') {
      $.ajax({
      type: "POST",
      url: "php/search/clsearch",
      data: dataString,
      cache: false,
      success: function(html)
      {
      $("#resultado-cita").html(html).show();
      $(document).ready(function(){
$('.dropdown-button').dropdown();
M.AutoInit();
});$('.close').click(function(){
$(".hide-this").hide();
$(".close").hide();
});
}});}return false;
}});

jQuery("#resultado-cita").on("click",function(e){
var $clicked = $(e.target);
var $name = $clicked.find('.name-cita').html();
var decoded = $("<div/>").html($name).text();
$('.selected-user').show();
$('.selected-user').html(decoded);
});


});