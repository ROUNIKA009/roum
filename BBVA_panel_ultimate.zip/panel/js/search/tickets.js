$(function(){
$(".search-tickets").keyup(function() {
if($(this).val().length > 2) {
var inputSearch = $(this).val();
var input = $('.current').text();
var dataString = 'searchword='+ inputSearch;
var seis = 'calendar='+ input;
if(inputSearch!='') {
      $.ajax({
      type: "POST",
      url: "php/search/tickets",
      data: "searchword="+inputSearch,
      cache: false,
      success: function(html){
$("#resultado-ticket").html(html).show();
$('.edit-ticket').click(function(){
var serverId = $(this).data('id'); //this binds to html input
editmaster(serverId);
});
$('.close').click(function(){
$(".display_box").hide();
$("#resultado-ticket").hide();
$(".close").hide();
});
      }});}return false;
}});
});