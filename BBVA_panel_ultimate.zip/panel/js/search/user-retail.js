$(function(){
$(".search").keyup(function() {
if($(this).val().length > 0) {
var inputSearch = $(this).val();
var dataString = 'searchword='+ inputSearch;
if(inputSearch!='') {
      $.ajax({
      type: "POST",
      url: './php/calendar/options/client',
      data: dataString,
      cache: false,
      success: function(html)
      {
      $("#divResult").html(html).show();
      }});}return false;
}});

jQuery("#divResult").on("click",function(e){
var $clicked = $(e.target);
var $name = $clicked.find('.namexx').html();
var decoded = $("<div/>").html($name).text();
$('.chip').show();
$('.sel-usr').show();
$('.sel-usr').html(decoded);

var $name = $clicked.find('#iduser').val();
var decoded = $("<div/>").html($name).text();
$('.id-client').show();
$('.id-client').html(decoded);
});
jQuery(document).on("click", function(e) {
var $clicked = $(e.target);
if (! $clicked.hasClass("search")){
jQuery("#divResult").fadeOut();
}});
$('#inputSearch').click(function(){
jQuery("#divResult").fadeIn();
});});