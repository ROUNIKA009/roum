$(function(){
$(".search-citas").keyup(function() {
if($(this).val().length > 2) {
var inputSearch = $(this).val();
var input = $('.current').text();
var dataString = 'searchword='+ inputSearch;
var seis = 'calendar='+ input;
var checkbox = document.getElementById('mycheckbox');
var custom_search = checkbox.checked;
if (custom_search === true) {
if(inputSearch!='') {
      $.ajax({
      type: "POST",
      url: "php/search/citas_old",
      data: "searchword="+inputSearch+"&calendar="+input,
      cache: false,
      success: function(html)
      {
      $("#resultado-cita").html(html).show();
      $('.close').click(function(){
$(".display_box").hide();
$("#resultado-cita").hide();
$(".close").hide();
});}});}return false;

}
if (custom_search === false) {
if(inputSearch!='') {
      $.ajax({
      type: "POST",
      url: "php/search/citas",
      data: "searchword="+inputSearch+"&calendar="+input,
      cache: false,
      success: function(html)
      {
      $("#resultado-cita").html(html).show();
      $('.close').click(function(){
$(".display_box").hide();
$("#resultado-cita").hide();
$(".close").hide();
});}});}return false;
}
}});

jQuery("#resultado-cita").on("click",function(e){
var $clicked = $(e.target);
var $name = $clicked.find('.name-cita').html();
var decoded = $("<div/>").html($name).text();
$('.selected-user').show();
$('.selected-user').html(decoded);
});
$('#citabus').click(function(){
});});