$(function(){
$('.searchx').keyup(function() {
var inputSearch = $(this).val();
var dataString = 'searchword='+ inputSearch;
if(inputSearch!='') {
$.ajax({
type: 'POST',
url: '../php/retail/services',
data: dataString,
cache: false,
success: function(html){
$('#divResultx').html(html).show();
}});}return false;
});
$("#divResultx").on('click', function(e){
var $clicked = $(e.target);
var $name = $clicked.find('.namex').text();
var $namex = $clicked.find('.jhh').text();
var hhg = Math.floor((Math.random() * 10000) + 1);
var decoded =  '<tr class="'+hhg+'"/><td class="selling">' + $name + '</td>' + '<td id="price-tag">' + $namex +  '</td>' + '<td class="selling"><a id="wave-delete" class="waves-effect waves-teal btn-flat" data-id="'+hhg+'">Eliminar</a></td>';
document.getElementById('content-services').innerHTML += decoded;
$('.notice').hide();
new totalxx();
jQuery('#divResultx').fadeOut();
});

jQuery(document).on('click', function(e) {
var $clicked = $(e.target);
if (! $clicked.hasClass('searchx')){
jQuery('#divResultx').fadeOut();
}});
$('#inputSearchx').click(function(){
jQuery('#divResultx').fadeIn();
});});