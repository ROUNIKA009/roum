$('.user-reg').click(function(){
var usuario = $("#nombre2").val('');
var usuario = $("#usuario2").val('');
var correo = $("#email2").val('');
var password = $("#password2").val('');
var telefono = $("#telefono2").val('');
M.updateTextFields();
$('#modal-users').modal('open');
});
$('.admin-reg').click(function(){
var nombre = $("#usuario-nombre").val('');
var usuario = $("#usuario-adm2").val('');
var correo = $("#email-adm2").val('');
var password = $("#password-adm2").val('');
$("#telefono-adm2").removeClass('valid');
$("#usuario-nombre").removeClass('valid');
$("#usuario-adm2").removeClass('valid');
$("#email-adm2").removeClass('valid');
$("#password-adm2").removeClass('valid');
$("#telefono-adm2").removeClass('valid');
M.updateTextFields();
$('#modal-admin').modal('open');
});
$('.HGFJHDGS').click(function(){
var nombre = $("#nombre2").val();
var usuario = $("#usuario2").val();
var correo = $("#email2").val();
var password = $("#password2").val();
var telefono = $("#telefono2").val();
$("#nombre2").removeClass('valid');
$("#usuario2").removeClass('valid');
$("#email2").removeClass('valid');
$("#password2").removeClass('valid');
$("#telefono2").val('');
$("#telefono2").removeClass('valid');
var range = 'empleado';
$.ajax({
type: "POST",
url: "php/register/user",
dataType: "html",
data: "usuario="+usuario+"&correo="+correo+"&password="+password+"&telefono="+telefono+"&rango="+range+"&nombre="+nombre,
success: function(data){
$('.not-show').show();
document.getElementById("announce").innerHTML = data;
$('#modal-users').modal('close');
new users_table();
setTimeout(function(){$('#announce').html(''); $('.not-show').hide();}, 3000);
}});
});
$('.XXHGFHJK').click(function(){
var nombre = $("#usuario-nombre").val();
var usuario = $("#usuario-adm2").val();
var correo = $("#email-adm2").val();
var password = $("#password-adm2").val();
var telefono = $("#telefono-adm2").val();
var range = 'root';
$.ajax({
type: "POST",
url: "php/register/user",
dataType: "html",
data: "usuario="+usuario+"&correo="+correo+"&password="+password+"&telefono="+telefono+"&rango="+range+"&nombre="+nombre,
success: function(data){
$('.not-show').show();
document.getElementById("announce").innerHTML = data;
$('#modal-admin').modal('close');
new users_table();
setTimeout(function(){$('#announce').html(''); $('.not-show').hide();}, 3000);
}});
});