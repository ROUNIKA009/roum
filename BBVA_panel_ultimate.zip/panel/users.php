<!DOCTYPE html>
<html lang="es">
    <head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta charset="UTF-8">
<title>Panel - Usuarios</title>
        <link rel="shortcut icon" type="image/png"  href="./favicon.png"/>
<!--Import materialize.css-->
<link type="text/css" rel="stylesheet" href="css/material.css"/>
<link type="text/css" rel="stylesheet" href="css/custom.css" />
  <link rel="stylesheet" href="css/sweetalert2.min.css">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script src="js/sweetalert2.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/datatables.min.css"/>
<script type="text/javascript" src="js/datatables.js"></script>
<!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support -->
    </head>
    <body>
<?php
session_start();
include 'php/gravatar/get.php';
include 'php/database/db.php';
include 'php/login/true.php';
if ($userRow['rango'] === 'empleado') {
header('Location: ./index');
}
?>
   <!-- Start Header -->
  <div class="navbar-fixed">
    <nav class="cyan darken-1"><a href="#" class="brand-logo"><img class="imagi" src="./images/logo2.png"></a>
        <ul class="right hide-on-med-and-down">
          <?php if ($userRow['rango'] === 'root'): ?>
          <li><a href="./index">Inicio</a></li>
<li class="active"><a href="./users.php">Usuarios</a></li><?php endif; ?>
          <li><a class="dropdown-trigger btn custom-profile" href="#" data-target="dropdown1"><?php echo htmlentities($userRow['username']); echo '<img src="'.get_profile(''.$userRow['email'].'').'" class="circle profile-pic">'; ?></a></li>
        <ul id="dropdown1" class="dropdown-content">
          <li><a href="./logout.php?rel=<?php echo @$_COOKIE['identificator']; ?>"><i class="material-icons">keyboard_tab</i>Salir</a></li>
      </ul>
        </ul>
  <ul id="slide-out" class="sidenav">
<ul id="slide-out" class="side-nav" style="transform: translateX(0px);">
<img src="./images/logo.png" class="logo-active">
<div class="divider"></div>
<?php if ($userRow['rango'] === 'root'): ?>
          <li><a href="./index.php">Inicio</a></li>
<li class="active"><a href="./users.php">Usuarios</a></li>
 <div class="divider"></div>
<?php endif; ?>
<li><a class="subheader">Opciones de Usuario</a></li>
<li class="no-padding">
<ul class="collapsible collapsible-accordion">
<li>
<a class="collapsible-header"><?php echo '<img src="'.get_profile(''.$userRow['email'].'').'" class="circle profile-pic-mobile">'; echo htmlentities($userRow['username']); ?></a>
<div class="collapsible-body">
<ul>
<li><a href="./logout.php?rel=<?php echo @$_COOKIE['identificator']; ?>"><i class="material-icons">keyboard_tab</i>Salir</a></li>
</ul>
</div>
</li>
</ul>
</li>
</ul>
<ul class="right hide-on-med-and-down">
<ul id="dropdown1" class="dropdown-content">
<li><a href="./logout.php?rel=<?php echo @$_COOKIE['identificator']; ?>"><i class="material-icons">keyboard_tab</i>Salir</a></li>
</ul></li>
</ul>
  </ul>
  <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
    </nav>
  </div>
<!-- End header -->
   <div class="l-loader">
    <div class="text">
        <span class="letter">W</span><span class="letter">I</span><span class="letter">N</span>E<span class="letter pulse"></span>
    </div>
</div>
<!-- End Preloader -->
<div class="hide session-crypt"></div>
 <!-- Modal Structure -->
  <div id="modal-editer" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Editar Usuario</h4>
<div class="modal-edit"></div>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat edit-button close-ios">Editar</a>
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat close-ios">Cerrar</a>
    </div>
  </div>
  <div id="modal-admin" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Registrar Cuenta</h4>
        <div class="card-panel gradient-45deg-indigo-blue medium-small white-text">Es necesario rellenar los campos : Usuario, Correo y Contraseña, de lo contrario, el registro de cuenta no será procesado</div>
      <div class="card-panel indigo lighten-2 no-shadow">
          <span class="white-text">Recuerda que al registrar una cuenta tomara las mayusculas y minusculas.</span>
        </div>

 <div class="row">
    <div class="input-field col s12">
        <input id="usuario-nombre" type="text" class="validate" placeholder="Nombre Completo..">
        <label for="usuario-nombre">Nombre</label>
      </div>
    </div>

 <div class="row">
    <div class="input-field col s12">
        <input id="usuario-adm2" type="text" class="validate" placeholder="Usuario.. Ej : stargate">
        <label for="usuario-adm2">Usuario</label>
      </div></div>

 <div class="row">
        <div class="input-field col s12">
        <input id="email-adm2" type="email" class="validate" placeholder="Correo Electrónico..">
        <label for="email-adm2">Email</label>
      </div></div>

 <div class="row">
        <div class="input-field col s12">
        <input id="password-adm2" type="password" class="validate" placeholder="Contraseña : Procura que sea segura..">
        <label for="password-adm2">Contraseña</label>
      </div></div>
</div>
    <div class="modal-footer">
      <a href="#!" class="waves-effect waves-green btn-flat XXHGFHJK close-ios">Guardar</a>
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat close-ios">Cerrar</a>
    </div>
  </div>
<!-- Start Content -->
<div class="row">
  <div class="col s12 m3">
<div class="custom-top">
<?php if ($userRow['rango'] === 'root'): ?>
 <button class="btn waves-effect blue-grey lighten-1 no-radius admin-reg open-ios" type="submit" name="action">Registrar Cuenta</button>
<?php endif; ?>
</div>
  </div>
    <div class="col s12 m9">
<div class="card-panel blue-grey lighten-1 no-shadow">
          <span class="white-text">Las ediciones y las modificaciones son posibles y en tiempo real.</span>
        </div>
        <div class="card-panel teal lighten-2 no-shadow not-show">
          <span class="white-text" id="announce"></span>
        </div>
<main></main>
    </div>
</div>
      </div>
<!-- End Content -->
<!--Import materialize.js-->
<script type="text/javascript" src="js/users/init.js"></script>
<script type="text/javascript">
M.AutoInit();
setTimeout(function(){$('.l-loader').addClass("loading-step-1");},50);
  $(document).ready(function(){
    $('.not-show').hide();
    // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
$('#modal-users').modal();
$('#modal-admin').modal();
$('#modal-editer').modal();
  });
document.addEventListener("DOMContentLoaded", function(){
setTimeout(function(){$('.l-loader').hide();},1000);});
new users_table();
function users_table(){
$.ajax({
url: "php/tables/users.php",
success: function(data) {
$('main').html(data);

//Functions to delete and edit
$('.delete').click(function(){
var serverId = $(this).data('id'); //this binds to html input
delete_action(serverId);
});

$('.edit').click(function(){
var serverId = $(this).data('id'); //this binds to html input
edit_action(serverId);
});}});}
<?php  if ($userRow['rango'] === 'root'): ?>
function delete_action($id) {
swal.fire({
  title: 'Estas Seguro?',
  text: "Recuerda que esta acción es irreversible",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Si, Eliminar!',
  cancelButtonText: 'Cancelar'
}).then(function () {
  swal.fire(
    'Eliminado!',
    'Acción realizada correctamente.',
    'success'
  )
  // edit this shit
var id = $id;
$.ajax({
type: "POST",
url: "php/actions/usrdelete.php",
dataType: "html",
data: "id="+id
}).responseText;
M.toast({html:'Usuario Eliminado Correctamente'}, 4000);
setTimeout(function(){ new users_table(); }, 1000);
}).catch(swal.fire.noop);
};

function edit_action($id) {
var id = $id;
$.ajax({
type: "POST",
url: "php/clases/usedit.php",
data: "id="+id,
success: function(data) {
$('.modal-edit').html(data);
$('#modal-editer').modal('open');
M.updateTextFields();
}});};
<?php endif; ?>

$('.edit-button').click(function(){
var id = $('#id-edit').val();
var username = $('#username-edit').val();
var email = $('#email-edit').val();
var nombre = $('#nombre-edit').val();
$.ajax({
type: "POST",
url: "php/actions/usupdate.php",
data: "id="+id+"&username="+username+"&email="+email+"&nombre="+nombre,
success: function() {
M.toast({html:'Usuario Editado Correctamente'}, 4000);
setTimeout(function(){ new users_table(); }, 400);
}});});
</script>
</body></html>