<?php
/**
* PANEL PRIV8 LIVE
* Load@world
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @license    Privative
* @version    Version @package_version@
* @since      Class available since Version 1.0.0
*/
/* Load Required Files */
include 'php/database/db.php';
session_start();
/* Check if is real are logged and destroy the session */
if (!isset($_SESSION['userSession'])) {
header("Location: login.php");

}

/* If not logged, go to the login */
if(isset($_SESSION['userSession'])!="") {
header("Location: index.php");
}

if (isset($_GET['logout'])) {
unset($_SESSION['userSession']);
$e = @htmlspecialchars($connection->real_escape_string($_GET['identificator']));
$querx = $connection->query("DELETE FROM secure WHERE hash ='".$e."'");
setcookie('identificator', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('selection', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('entrance', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('agend', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('exit', '', time() - (10 * 365 * 24 * 60 * 60), '/');
header("Location: login.php?rel=logout");
}

if (isset($_GET['rel'])) {
unset($_SESSION['userSession']);
$e = @htmlspecialchars($connection->real_escape_string($_GET['identificator']));
$querx = $connection->query("DELETE FROM secure WHERE hash ='".$e."'");
setcookie('identificator', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('selection', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('entrance', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('agend', '', time() - (10 * 365 * 24 * 60 * 60), '/');
setcookie('exit', '', time() - (10 * 365 * 24 * 60 * 60), '/');
header("Location: login.php?rel=exit");
}