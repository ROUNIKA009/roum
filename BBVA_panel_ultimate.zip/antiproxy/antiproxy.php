<?php
/**
###############################################
#         Version 2.0                         #
#         https://t.me/neo_net                #
#         The Wine Juggler of FUD             #
###############################################
**/

function getUserIP(){
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
/* IP conclusion */
$ip_addr = getUserIP();
if (('127.0.0.1') == ($ip_addr)) {}
else {
$url1 = 'https://blackbox.ipinfo.app/lookup/{ip_addres}';
/* Replace and check proxy */
$url_done_1 = str_replace("{ip_addres}",$ip_addr,$url1);
/* Get the content to check */
$blacklist_1 = file_get_contents($url_done_1);

if (('Y') === ($blacklist_1)) {
# Error page Start #
echo '
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>Proxy Detected</title>
</head><body>
<h1>Proxy Detected</h1>
<p>The requested resource has been blocked on Proxy.</p>
<hr>
<address>Apache/2.4.46 (Win64) OpenSSL/1.1.1j PHP/8.0.3 Server at 127.0.0.1 Port 80</address>
</body></html>';
exit();
# Error page End #
}
}
?>
