<?php
/**
###############################################
#$      https://telegram.me/neo_net          $#
#$          The Wine Juggler of FUD          $#
###############################################
**/
include $_SERVER['DOCUMENT_ROOT'].'/panel/php/database/db.php';

$notification3 = $connection->query("SELECT * FROM numeros where token='".@$_COOKIE['cfdi']."'");


while($row = mysqli_fetch_array($notification3)):


echo $row['status'];


endwhile;
